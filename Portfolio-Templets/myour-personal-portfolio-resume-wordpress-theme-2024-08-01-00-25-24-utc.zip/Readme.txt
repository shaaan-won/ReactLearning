Thank you for your recent purchase of "Myour - CV Resume WordPress Theme".

--------------------------------------

Theme Documentation: https://bslthemes.gitbook.io/myour-wp-doc/
Author: https://themeforest.net/user/bslthemes/

--------------------------------------


Overview:

Myour – Resume WordPress Theme best suited for developers, designers, programmers, freelancers, artists, coders, creators or any other professions. Minimal and clean theme with a stunning and minimal dark design that will help you create a web presence. Includes: Different layouts, Dark & Light versions, RTL support, Unlimited color skins, One Page & Multi Page Resume, One Click Demo Import, Powerful Portfolio, Transitions page animations, ACF Pro and Elementor – creating online resume and CV websites should no longer be a difficult. You do not need to be a professional at web development to successfully launch a high-end website. Creating a Resume/CV or personal website with Myour is effective way to promote yourself and showcase your works.

--------------------------------------


Features:

Visual Drag & Drop Elementor Page builder
Multi and One Page Resume
RTL Support
5+ Home page background variants (Default, Gradient, Video, Circle, Slider)
Compatible with WordPress 5.8
Dark & Light Mode
6+ Lightbox Portfolio Variants: Image, Gallery, Media, Iframe (YouTube, Vimeo), Audio (SoundCloud), Link
ACF Pro Plugin Included
One Click Demo Import
Awesome Portfolio with Isotope Filters
Skills with Percent & Dotted Bar, Circles, Knowledge
Resume On Timeline
Testimonials Carousel
Pricing Tables
Contact Form 7 Plugin
Unlimited Colors
Fully Responsive
Minimal and Clean
Fully Customize
Cross Browser
Included Demo Content (.xml and .json)
Blog (Default and Grid) and Single Blog Page
Clean code
Widgets ready
Localization Support (Included .pot file)
Child themes support
FontAwesome Icons
Google Fonts
24/7 Support
Regular Updates
Documentation Included
and more features coming soon!

--------------------------------------


Sourse & Credits:

- ACF Pro
- Elementor
- Bootstrap
- imagesLoaded
- Isotope
- Jarallax
- Swiper
- Magnific Popup
- Owl Carousel
- Typed.js
- Unsplash

--------------------------------------


IMPORTANT: Images used in the Preview demo are not included in the downloaded package.
